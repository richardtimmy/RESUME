# Resume

A Pen created on CodePen.io. Original URL: [https://codepen.io/richardtimmy/pen/RwYMZGd](https://codepen.io/richardtimmy/pen/RwYMZGd).

